def percent(value, rate):
    return value * rate / 100
